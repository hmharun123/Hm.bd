window.addEventListener("load", function() {
  document.getElementById("preloader").style.display = "none";
});
let text = ["ডিজাইনার", "এডিটর", "মার্কেটার"];
let index = 0;
setInterval(() => {
  document.getElementById("typing-text").textContent = text[index];
  index = (index + 1) % text.length;
}, 2000);
